""" 
variables globales
"""
import pygame

# colores
color_negro    = (   0,   0,   0) 
color_blanco   = ( 255, 255, 255) 
color_azul     = (   0,   0, 255)
color_verde    = (   0, 255,   0)
color_red      = ( 255,   0,   0)  


# dimensiones pantalla
ancho_pantalla  = 900
alto_pantalla = 640

#efecto lluvia
contador=0